define( function ( require ) {

	"use strict";

	return {
		app_slug : 'app-android',
		wp_ws_url : 'https://ivan.porelbierzo.es/wp-appkit-api/app-android',
		wp_url : 'https://ivan.porelbierzo.es',
		theme : 'q-android',
		version : '',
		app_type : 'phonegap-build',
		app_title : 'Iván López Freelance',
		app_platform : 'android',
		app_path: '',
		gmt_offset : 0,
		debug_mode : 'off',
		auth_key : 'p2X%gB.yMM,(,;zvZoNWaWtgWIqc)>(XZ:T?7Z$>7o=){W5k5v(&z5~~HHEMgAFn',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
